import java.net.*;
import java.io.*;
class IPser
{
	public static void main(String args[])
	{
		try
		{
			ServerSocket ss=new ServerSocket(222);
			System.out.println("Destination...");
			while(true)
			{
				
				Socket s=ss.accept();
				DataInputStream in=new DataInputStream(s.getInputStream());
				byte b[]=new byte[in.available()];
				String source = in.readUTF();
				String dest = in.readUTF();
				String msg = in.readUTF();
				System.out.println("Source Address: "+source);
				System.out.println("Destination Address: "+dest);
				System.out.println("Message:\n "+msg);
				new IPdest(source, dest, msg);
				DataOutputStream out=new DataOutputStream(s.getOutputStream());
				out.writeUTF("I have received  message");
			}
		}
		catch(Exception e)
		{ e.printStackTrace(); }
	}
}