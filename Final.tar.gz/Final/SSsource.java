
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.event.*;
public class SSsource extends JFrame

{
	 JLabel jl1;
	 JLabel jl2;
	 JLabel j13;
	 JLabel jl4;
     JButton jb1;
	 JButton jb2;
	 JButton jb3;
	 JTextField jt1;
	 JTextField jt2;
	 JTextField jt3;
	 String msg="";
	 static JTextArea jta;
	 JScrollPane jsp,jsp1;
	 Container c;
	 JList jlist;
	 JLabel jl5;
	 String str="";
	 String str1="";
	 String path="";
	 String dest="";
	 long avglat;
	long vsize;
	
	long favglat = 0;
	 File f;
	 Vector v = new Vector();
	 Vector vlat = new Vector();
Vector v1 = new Vector();
	 String sender="";
	 public  String temp="";
	 public  String te="";
	  public  String router="";
	  public  String empty="";
	  Long latency;
		static double dss;


	 SSsource()

	 {   
	 	 System.out.println("Source.....\n");
	 	 Vector s=nodelist();
		 SSnet nt = new SSnet();
		v1 = SSnet.vnode;
		
			
		 
		 jl1=new JLabel("Enter The Destination Name ");
		jl1.setForeground(new Color(218, 173, 173));
		
		 jl2=new JLabel("Choose File ");
		 jl2.setForeground(new Color(218, 173, 173));
		 j13=new JLabel("Route Nodes");
		 j13.setForeground(new Color(218, 173, 173));	
		 
		 jl4=new JLabel("Latency");
jl4.setForeground(new Color(218, 173, 173));
		 jb1=new JButton("Send");
		 jb2=new JButton("Reset");
		 jb3=new JButton("Browse..");
		 
		 jt1=new JTextField(10);
		 jt2=new JTextField(10);
		  jt3=new JTextField(10);
	
		 jta=new JTextArea();
		 jsp=new JScrollPane(jta);
		 jlist = new JList(v1); // v1 - net view or s - user defined
		 jsp1=new JScrollPane(jlist);
		 //JOptionPane p1 = new JOptionPane();
    
		 c=getContentPane();
		this.setTitle("Selfish Routing - extends JFrame");
		this.setSize(new Dimension(607, 546));
		c.setBackground(new Color(83, 90, 113));
		 c.setLayout(null);
		 c.add(jl1);
		 c.add(jt1);
		 c.add(jl2);
		 c.add(j13);
		 c.add(jl4);
		 c.add(jb3);
		 c.add(jb1);
		 c.add(jb2);
		 c.add(jsp);
		 c.add(jt2);
		 c.add(jsp1);
		 c.add(jt3);
		 
		 jl1.setBounds(70,100,200,25);
		 jt1.setBounds(300,100,100,25);
		 jl2.setBounds(70,135,200,25);
		 jt2.setBounds(300,135,100,25);
		 jb3.setBounds(300,170,100,25);
		 jsp.setBounds(410,100,280,400);
		 jb1.setBounds(150,225,100,25);
		 jb2.setBounds(300,225,100,25);
		 jsp1.setBounds(700,100,100,400);
		 j13.setBounds(700,80,100,25);
		 jl4.setBounds(70,300,200,25);
		 jt3.setBounds(300,300,100,25);

		 this.setTitle("Selfish Source Routing");
		 setSize(800,800);
		 setVisible(true);
		 jb3.addActionListener(new ActionListener() {

		 public void actionPerformed(ActionEvent ae)
		{
				JFileChooser jf=new JFileChooser();

				int m=jf.showOpenDialog(null);
				if(m==JFileChooser.APPROVE_OPTION)
			{
				   f=jf.getSelectedFile();
				   str=f.getPath();
				   path=f.getAbsolutePath();
				   
				try
				{
				   FileInputStream fis=new FileInputStream(str);
				   byte b[]=new byte[fis.available()];
				   jt2.setText(str);
				   fis.read(b);
				   str1=new String(b);
				   jta.setText(str1);
				   fis.close();
			   }
			   catch(Exception ui){}
			} //if
			} // ap
		} );
		jb1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent ae)
			{
				
	         	try{
	         	
	        
	 		 dest=jt1.getText();
	 	
	 		 sender=((InetAddress.getLocalHost()).getHostAddress());
	 		 System.out.println("Sender is " +  sender);
	 	
	 		 Socket rousoc=new Socket(router,555);
	 		 DataOutputStream out=new DataOutputStream(rousoc.getOutputStream());
	 	     String msg = str1;
	 	     Long intime=System.currentTimeMillis(); // System.nanoTime();
  
			out.writeUTF(router);
			out.writeUTF(sender);
			out.writeUTF(dest);
			out.writeUTF(msg);
		 
			DataInputStream inn=new DataInputStream(rousoc.getInputStream());  //packet acknowledgement0
			System.out.println("\nDestination Acknowledgement:" +  inn.readUTF());
			Long outtime=System.currentTimeMillis();
JOptionPane.showMessageDialog(null, "File has been transferred","Message", JOptionPane.OK_CANCEL_OPTION);
			//System.out.println("MILLISECOND: " + calendar.get(Calendar.MILLISECOND));
    
			latency=outtime-intime;
			String strlatt = ""+latency+"#";
			FileOutputStream flat = new FileOutputStream("lat2.txt", true);
			
			flat.write(strlatt.trim().getBytes());
			

			System.out.println("\n latency:" +  latency);
			vlat.addElement(latency);
			vsize = vlat.size();
			long avglat1 = 0;
			System.out.println(vlat);
			System.out.println("Vector Size..."+vsize);
			Enumeration en = vlat.elements();
			while(en.hasMoreElements())
			{
				Object obj = en.nextElement();
				String stravg = obj.toString();
				avglat = Long.parseLong(stravg);
				avglat1 = avglat1 + avglat;
				favglat = avglat1/vsize;
				System.out.println("string average..."+stravg);
				System.out.println("Long average..."+avglat);
			}
			String strlat = String.valueOf(favglat);
			Long avg1 = new Long(favglat);
			double d = Double.valueOf(avg1);
			dss = d; 
			System.out.println("Final Average Latency..."+favglat);
			jt3.setText(strlat);
			
			//System.out.println("" + inn.readUTF());
			
			       }
			
			catch(Exception e) 
				{ 
				System.out.println(e); 
				}

			
	 	   }
	    } );
	        try{
	        jlist.addListSelectionListener(new ListSelectionListener() { 
 			public void valueChanged(ListSelectionEvent e1) 
 			{ 
 				jlist_valueChanged(e1); 
 			}
 			 //jsp1.setViewportView(jlist); 
	 } );
	 }
	 	catch(Exception e2) 
	 		{
	 			 System.out.println("" + e2); 
	 		}
	 		
	 	/*	jb2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent ae)
			{
				new (String.RESET);
				
			}
	 		});*/
	 
 
   	jb2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent ae)
			{
				
	         	try{
	         		jt1.setText(empty);
	         		jt2.setText(empty);
	         		jta.setText(empty);
	         	   }
	         	catch(Exception e3) 
	 	           	{
	 			 System.out.println("" + e3); 
	 		        }
			}
   	});
   	   }
   	//sour
	 
	 	private void jlist_valueChanged(ListSelectionEvent e1) 
 	{ 
 		System.out.println("\njList1_valueChanged(ListSelectionEvent e) called."); 
 		if(!e1.getValueIsAdjusting()) 
 		{ 
 			Object o = jlist.getSelectedValue(); 
 			System.out.println("" + ((o==null)? "null" : o.toString()) + " is selected."); 
 			 router=o.toString();
 			System.out.println("\nRouter is" +  router);
 			 
 		} 
 	} 
	    public Vector nodelist()
   	    {
   	
   		try
				{
				   String fileloc="nodes.txt";	
				   FileInputStream fin1=new FileInputStream(fileloc);
				   File f2 = new File(fileloc);

			    byte b[] = new byte[(int)f2.length()];
		
			fin1.read(b);
			String nodes1 = new String(b);
			StringTokenizer st= new StringTokenizer(nodes1,"#");
			System.out.println("Routers in the network");
		while(st.hasMoreTokens())
		{
		 te=st.nextToken();
		 v.addElement(te);
		 
		 System.out.println(te);
 		
 		}
				//System.out.print(""+ msg);
			fin1.close();
			//System.out.println(v);
			   } //try
			   catch(Exception ui)
			   	{System.out.print(""+ ui);
			   	}
			  return v;
			   
   }
	 	
	 	     
	 	   
   

	 public static void main(String a[])

	 {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		 
		try
		{
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}
		catch (Exception ex)
		{
			System.out.println("Failed loading L&F: ");
			System.out.println(ex);
		}
		 new SSsource();
		// System.out.println("Source");
		 
	 }
 
   
 }   