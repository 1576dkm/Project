/**
 * @(#)srouting.java
 *
 *
 * @author 
 * @version 1.00 2006/12/7
 */
import java.io.*;
import java.net.*;
import java.sql.*;

public class SOhash {
		static String froot;
        	
    /**
     * Creates a new instance of <code>srouting</code>.
     */
    public SOhash(String des) {
    try
		{	
			System.out.println("hai...........");
			InetAddress ip=InetAddress.getLocalHost();
    	String localip = ip.getHostName();
    	String dest = des; 
    	String fdest = null;
    
    	 //static String froot;
    	 	
    	 Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
         			String dataSourceName = "router";
         			String dbURL = "jdbc:odbc:" + dataSourceName;
         			Connection con = DriverManager.getConnection(dbURL, "",""); 
   		 			Statement st = con.createStatement();
   		 			ResultSet rs = st.executeQuery("select * from DEST_TABLE ");
   		  
			   		  while(rs.next())
   		  				{
   			  		String destnode = rs.getString(1);
   			  		
   			  		//String rootnode = rs.getString(2);
 			  		//String right = rs.getString(3);
 			  		
 			  			System.out.println("Dest Node..."+destnode);
 			  		
 			  		//	System.out.println("Right Node..."+right);
 			  		if(dest.equals(destnode))
 			  		{
 			  			String rootnode = rs.getString(2);
 			  			froot = rootnode;
 			  			FileOutputStream fos = new FileOutputStream("root.txt");
 			  				fos.write(froot.getBytes());
 			  			System.out.println("Root Node..."+rootnode);
 			  			
 			  		}
   		  				}
   		  							  		
		}
	catch(Exception e)
	{}
 			  		
 			  			
 			  
 			  
 			  // private String fdest = null;
   			  	/*		if (currnode.equalsIgnoreCase(dest))
   			  			{
   				  		 fdest = currnode;
   				  			System.out.println("Checked Current Node..."+currnode);
   			  			}
   			  			else if (left.equalsIgnoreCase(dest)) {
   				  		 fdest = left;
   				  		System.out.println("Checked Left Node..."+left);
						}
   			  			else if (right.equalsIgnoreCase(dest)) {
   				  		 fdest = right;
   				  		System.out.println("Checked Right Node..."+right);
						}
   			  			else if(localip.equalsIgnoreCase(currnode))
   			  			{		  			
   				  			 
   					 		 root = rs.getString(4);
   					 		 fdest = root; 
   					 		System.out.println("Root Node For.."+currnode+"is.."+root);
   				  		}*/
   	
    }
    
    /**
     * @param args the command line arguments
     */
  
   /* public static void main(String[] args) {
    	new srouting();
        // TODO code application logic here
    }*/
    
}
