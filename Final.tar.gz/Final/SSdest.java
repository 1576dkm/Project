 import java.awt.*; 
 import java.awt.event.*; 
 import javax.swing.*; 
 import java.net.*;
 import java.io.*;

 public class SSdest extends JFrame implements ActionListener
 { 
 
 	private JLabel l1; 
 	private JLabel l2; 
 	private JLabel l3; 
 	private JTextField t1; 
 	private JTextField t2; 
 	private JTextField t3; 
 	private JTextArea jta; 
 	private JScrollPane jScrollPane1; 
 	private JButton b1; 
 	private JPanel contentPane; 
 	String router="";
 	String sender="";
	String dest="";
	String msg="";	
 	
  
 	public SSdest() 
 	{ 
 		super("selfish"); 
 	//nitializeComponent(); 
 	
  
 	//	this.setVisible(true); 
 	 
 			
 	//ivate void initializeComponent() 
 	 
 		l1 = new JLabel(); 
 		l2 = new JLabel(); 
 		l3 = new JLabel(); 
 		t1 = new JTextField(); 
 		t2 = new JTextField(); 
 		t3 = new JTextField(); 
 		jta = new JTextArea(); 
 		jScrollPane1 = new JScrollPane(); 
 		b1 = new JButton(); 
		l1.setForeground(new Color(218, 173, 173));
		l2.setForeground(new Color(218, 173, 173));
		l3.setForeground(new Color(218, 173, 173));
 		contentPane = (JPanel)this.getContentPane(); 
  
 		l1.setText("Sender Name"); 
 		
 		l2.setText("Receiver Name"); 
 		
 		l3.setText("Router"); 
 		jScrollPane1.setViewportView(jta); 
 	
 		b1.setText("DISPLAY"); 
 	
 	
 		contentPane.setLayout(null); 
		contentPane.setBackground(new Color(83, 90, 113));
 		addComponent(contentPane, l1, 33,51,83,25); 
 		addComponent(contentPane, l2, 33,95,88,27); 
 		addComponent(contentPane, l3, 42,551,68,26); 
 		addComponent(contentPane, t1, 189,49,100,27); 
 		addComponent(contentPane, t2, 189,91,100,30); 
 		addComponent(contentPane, t3, 185,551,117,29); 
 		addComponent(contentPane, jScrollPane1, 186,155,400,350); 
 		addComponent(contentPane, b1, 187,600,83,28); 
 			b1.addActionListener(this);
 		//	setDefaultCloseOperation(EXIT_ON_CLOSE);
       //this.setVisible(true);  	
 		this.setTitle("dest - extends JFrame"); 
 	//	this.setLocation(new Point(0, 0)); 
 	//	this.setSize(new Dimension(390, 300)); 
 			b1.addActionListener(this);
 			try
		{
			ServerSocket ss=new ServerSocket(666);
			System.out.println("Destination...");
			while(true)
			{
				
				Socket s=ss.accept();
				setSize(600,600);
				setVisible(true); 
				System.out.println("connected with Destination");
				DataInputStream in=new DataInputStream(s.getInputStream());
				//byte b[]=new byte[in.available()];
				 router=in.readUTF();
				 sender=in.readUTF();
				 dest=in.readUTF();
				 msg=in.readUTF();
				
				System.out.println("Router name:" +  router);
				System.out.println("sender name:" +  sender);
				System.out.println("Destination name:" +  dest);
				System.out.println("File content is:\n\n" +  msg);
				
				String ack="File received in Destination";
				DataOutputStream out=new DataOutputStream(s.getOutputStream());
				out.writeUTF(ack);
				s.close();
			}
		}
		catch(Exception e1)
		{ e1.printStackTrace(); }
		
			/*b1.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) 
 			{ 
 				b1_actionPerformed(e); 
 			} 
  
 		}); */ //b1.addActionListener();
 	} 
  
 	/** Add Component Without a Layout Manager (Absolute Positioning) */ 
 	private void addComponent(Container container,Component c,int x,int y,int width,int height) 
 	{ 
 		c.setBounds(x,y,width,height); 
 		container.add(c); 
 	} 
 			/*public void b1_actionPerformed(ActionEvent e) 
 	{ 
 		   System.out.println("\nb1_actionPerformed(ActionEvent e) called."); 
 		   	t1.setText(sender);
 		   	t2.setText(dest);
 		   	jta.setText(msg);
 		   	t3.setText(router);
 			
 	
  
 	} */
 		public void actionPerformed(ActionEvent ae)
	{

	 if(ae.getSource() == b1)
		     {
		     	//System.out.println("\nb1_actionPerformed(ActionEvent e) called.");
		     	//if(lip.equals(sender))
		     	//{
		     	t1.setText(sender);
		     	t2.setText(dest);
		     	jta.setText(msg);
		     	t3.setText(router);	
		     	//}
			} 
			
	}  		
 			public static void main(String[] args) 
 	{
			JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		try
		{
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}
		catch (Exception ex)
		{
			System.out.println("Failed loading L&F: ");
			System.out.println(ex);
		} 
 			new SSdest(); 
 	} 
 }