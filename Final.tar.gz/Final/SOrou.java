import java.net.*;
import java.io.*;
import java.sql.*;
class SOrou
{
		
	public static void main(String args[])
	
	{
		try
		{
	/*		InetAddress ip=InetAddress.getLocalHost();
    	String localip = ip.getHostName();
    	 String fdest = null;
    	 String root = null;	
*/
	/*	private String currnode = null;
		private String left = null;
		private String right = null;
		private String dest = null;
		private String msg = null; 
		private String fdest = null;
		private String root = null;
	*/
	
			ServerSocket ss=new ServerSocket(333);
			System.out.println("Router...");
			while(true)
			{
				
				Socket s=ss.accept();
				DataInputStream in=new DataInputStream(s.getInputStream());
			String source = in.readUTF();
			String dest=in.readUTF();
			String msg=in.readUTF();
				/* try
   		 			{
   	
  		 			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
         			String dataSourceName = "router";
         			String dbURL = "jdbc:odbc:" + dataSourceName;
         			Connection con = DriverManager.getConnection(dbURL, "",""); 
   		 			Statement st = con.createStatement();
   		 			ResultSet rs = st.executeQuery("select * from CURR_TABLE ");
   		  
			   		  while(rs.next())
   		  				{
   			  		String currnode = rs.getString(1);
   			  		String left = rs.getString(2);
 			  		String right = rs.getString(3);
 			  			System.out.println("Left Node..."+left);
 			  			System.out.println("Right Node..."+right);
 			  			System.out.println("Current Node..."+currnode);
 			  // private String fdest = null;
   			  			if (currnode.equalsIgnoreCase(dest))
   			  			{
   				  		 fdest = currnode;
   				  			System.out.println("Checked Current Node..."+currnode);
   			  			}
   			  			else if (left.equalsIgnoreCase(dest)) {
   				  		 fdest = left;
   				  		System.out.println("Checked Left Node..."+left);
						}
   			  			else if (right.equalsIgnoreCase(dest)) {
   				  		 fdest = right;
   				  		System.out.println("Checked Right Node..."+right);
						}
   			  			else if(localip.equalsIgnoreCase(currnode))
   			  			{		  			
   				  			 
   					 		 root = rs.getString(4);
   					 		 fdest = root; 
   					 		System.out.println("Root Node For.."+currnode+"is.."+root);
   				  		}
   			  			
   					}
   		  
   		 			}catch(Exception e2)
   		 			{System.out.println(e2);}
   		 			*/
   		 			
				Socket reply=new Socket(dest,444);
				DataOutputStream dos=new DataOutputStream(reply.getOutputStream());
				dos.writeUTF(source);
				dos.writeUTF(dest);
				dos.writeUTF(msg);
				DataInputStream ser=new DataInputStream(reply.getInputStream());
				String ack = ser.readUTF();
				System.out.println(ack);
				DataOutputStream soc=new DataOutputStream(s.getOutputStream());
				soc.writeUTF(ack);
			}
		}
		catch(Exception e)
		{ e.printStackTrace(); }
}	}