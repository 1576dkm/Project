import java.net.*;
import java.io.*;
class SSrou 
{
	public static void main(String args[])
	{
		try
		{
			ServerSocket router1=new ServerSocket(555);
			System.out.println("Router...");
			//String dest="";
			//Socket destsoc=new Socket(dest,1111);
			while(true)
			{
				
				Socket s=router1.accept();
				DataInputStream in=new DataInputStream(s.getInputStream());
				String router=in.readUTF();
				String sender=in.readUTF();
				String dest=in.readUTF();
				String msg=in.readUTF();
				System.out.println("\nRouter name:" +  router);
				System.out.println("sender name:" +  sender);
				System.out.println("Destination name:" +  dest);
				System.out.println("File content is:\n\n" +  msg);
				
				
				 Socket destsoc=new Socket(dest,666);
				 DataOutputStream outd=new DataOutputStream(destsoc.getOutputStream());
				 outd.writeUTF(router);
			     outd.writeUTF(sender);
				 outd.writeUTF(dest);
				 outd.writeUTF(msg);
				
				//DataInputStream ser=new DataInputStream(s.getInputStream());
				//System.out.println("progrm ended");
				
				//String ack = ser.readUTF();
				//System.out.println("progrm ended");
				//System.out.println("Acknowledgement" + ack);
				//String ack="File received in router";
				DataInputStream in1=new DataInputStream(destsoc.getInputStream());
				String destack=in1.readUTF();
				System.out.println("\nDestination Acknoledgement:" + destack);
				DataOutputStream out=new DataOutputStream(s.getOutputStream());
				out.writeUTF(destack);
				//Thread.sleep(10);
		//out.writeUTF(destack);
				//System.out.println("File received");
				s.close();
				
			}
		}
		catch(Exception e)
		{ e.printStackTrace(); }
}	}