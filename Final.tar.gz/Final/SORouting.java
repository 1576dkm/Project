/****************************************************************/
/*                      SORouting	                            */
/*                                                              */
/****************************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

/**
 * Summary description for SORouting
 *
 */
public class SORouting extends JFrame
{
	// Variables declaration
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JTextField jTextField1;
	private JTextField jTextField2;
	private JTextField jTextField3;
	private JTextArea jTextArea1;
	private JScrollPane jScrollPane1;
	private JButton jButton1;
	private JButton jButton2;
	private JButton jButton3;
	private JPanel contentPane;
	File f1;
      	String str,str1;
	Vector v = new Vector();
  	long vsize;
	String stravg;
	long avglat;
	long avglat1 ;
	long favglat = 0;
	static double dso;

	// End of variables declaration


	public SORouting()
	{
		super();
		initializeComponent();
		//
		// TODO: Add any constructor code after initializeComponent call
		//

		this.setVisible(true);
	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always regenerated
	 * by the Windows Form Designer. Otherwise, retrieving design might not work properly.
	 * Tip: If you must revise this method, please backup this GUI file for JFrameBuilder
	 * to retrieve your design properly in future, before revising this method.
	 */
	private void initializeComponent()
	{
		jLabel1 = new JLabel();
		jLabel2 = new JLabel();
		jLabel3 = new JLabel();
		jTextField1 = new JTextField();
		jTextField2 = new JTextField();
		jTextField3 = new JTextField();
		jTextArea1 = new JTextArea();
		jScrollPane1 = new JScrollPane();
		jButton1 = new JButton();
		jButton2 = new JButton();
		jButton3 = new JButton();
		contentPane = (JPanel)this.getContentPane();
		  
		  
		//
		// jLabel1
		//
		jLabel1.setForeground(new Color(218, 173, 173));
		jLabel1.setText("Destination");
		//
		// jLabel2
		//
		jLabel2.setForeground(new Color(218, 173, 173));
		jLabel2.setText("File Path");
		//
		// jLabel3
		//
		jLabel3.setForeground(new Color(218, 173, 173));
		jLabel3.setText("Average Latency");
		//
		// jTextField1
		//
		jTextField1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jTextField1_actionPerformed(e);
			}

		});
		//
		// jTextField2
		//
		jTextField2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jTextField2_actionPerformed(e);
			}

		});
		//
		// jTextField3
		//
		jTextField3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jTextField3_actionPerformed(e);
			}

		});
		//
		// jTextArea1
		//
		//
		// jScrollPane1
		//
		jScrollPane1.setViewportView(jTextArea1);
		//
		// jButton1
		//
		jButton1.setText("SEND");
		jButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton1_actionPerformed(e);
			}

		});
		//
		// jButton2
		//
		jButton2.setText("RESET");
		jButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton2_actionPerformed(e);
				
			}

		});
		
		//
		// jButton3
		//
		jButton3.setText("BROWSE");
		jButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton3_actionPerformed(e);
			}

		});

		//
		// contentPane
		//
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(83, 90, 113));
		contentPane.setForeground(new Color(218, 173, 173));
		addComponent(contentPane, jLabel1, 14,95,71,22);
		addComponent(contentPane, jLabel2, 14,165,80,18);
		addComponent(contentPane, jLabel3, 12,359,91,25);
		addComponent(contentPane, jTextField1, 105,98,100,22);
		addComponent(contentPane, jTextField2, 108,161,100,24);
		addComponent(contentPane, jTextField3, 115,356,100,25);
		addComponent(contentPane, jScrollPane1, 228,67,291,369);
		addComponent(contentPane, jButton1, 13,277,86,28);
		addComponent(contentPane, jButton2, 116,277,83,28);
		addComponent(contentPane, jButton3, 58, 223, 107, 30);
		//
		// SORouting
		//
		this.setTitle("Selfish Overlay Routing - extends JFrame");
		this.setLocation(new Point(0, 0));
		this.setSize(new Dimension(544, 539));
	}

	/** Add Component Without a Layout Manager (Absolute Positioning) */
	private void addComponent(Container container,Component c,int x,int y,int width,int height)
	{
		c.setBounds(x,y,width,height);
		container.add(c);
	}

	//
	// TODO: Add any appropriate code in the following Event Handling Methods
	//
	private void jTextField1_actionPerformed(ActionEvent e)
	{
		System.out.println("\njTextField1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	private void jTextField2_actionPerformed(ActionEvent e)
	{
		System.out.println("\njTextField2_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	private void jTextField3_actionPerformed(ActionEvent e)
	{
		System.out.println("\njTextField3_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	}

	private void jButton1_actionPerformed(ActionEvent e)
	{
		System.out.println("\njButton1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

	String dest = jTextField1.getText();
	String msg = jTextArea1.getText();
	new SOsoc(dest, msg);
	JOptionPane.showMessageDialog(null, "File has been transferred","Message", JOptionPane.OK_CANCEL_OPTION);
	//long lat = soc.favglat1;
	long lat = SOsoc.lat1;
	System.out.println("hai..."+lat);
	v.addElement(lat);
	System.out.println("hello"+v);
	avglat1 = 0;
	
	vsize = v.size();
			System.out.println(v);
			System.out.println("Vector Size..."+vsize);
			Enumeration en = v.elements();
			while(en.hasMoreElements())
			{
				Object obj = en.nextElement();
				stravg = obj.toString();
				avglat = Long.parseLong(stravg);
				avglat1 = avglat1 + avglat;
				favglat = avglat1/vsize;
				System.out.println("string average..."+stravg);
				System.out.println("Long average..."+avglat);
			}
			System.out.println("Final Average Latency..."+favglat);
	
	Long avg1 = new Long(favglat);
	double d = Double.valueOf(avg1);
	dso = d; 
	//avg1 = avg;
	String favg = avg1.toString();
	System.out.println("Average Latency for IP Routing: "+favg);
	jTextField3.setText(favg);
		

	}

	private void jButton2_actionPerformed(ActionEvent e)
	{
		System.out.println("\njButton2_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
		
				jTextArea1.setText("");
				jTextField1.setText("");
				jTextField2.setText("");
				jTextField3.setText("");
				
	}
	private void jButton3_actionPerformed(ActionEvent e)
	{
		System.out.println("\njButton2_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here

		JFileChooser jf=new JFileChooser();

				int m=jf.showOpenDialog(null);
				if(m==JFileChooser.APPROVE_OPTION)
			{
				 //f1=new File();   
				f1=jf.getSelectedFile();
				 //f1=jf.getSelectedFile();
				   str=f1.getPath();
				  // path=f.getAbsolutePath();
				   
				try
				{
				   FileInputStream fis=new FileInputStream(str);
				   byte b[]=new byte[fis.available()];
				   jTextField2.setText(str);
				   fis.read(b);
				   str1=new String(b);
				   jTextArea1.setText(str1);
				   fis.close();
			   }catch(Exception e1)
				{
                          System.out.println(e1);  
				}

      }

	}


	//
	// TODO: Add any method code to meet your needs in the following area
	//






























 

//============================= Testing ================================//
//=                                                                    =//
//= The following main method is just for testing this class you built.=//
//= After testing,you may simply delete it.                            =//
//======================================================================//
	public static void main(String[] args)
	{
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		try
		{
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}
		catch (Exception ex)
		{
			System.out.println("Failed loading L&F: ");
			System.out.println(ex);
		}
		new SORouting();
	}
//= End of Testing =


}
