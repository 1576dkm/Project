//package org.jfree.chart.demo;
import java.awt.Color;
import java.awt.GradientPaint;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * A bar chart with only two bars - here the 'maxBarWidth' attribute in the renderer prevents
 * the bars from getting too wide.
 *
 */
public class chart1 extends ApplicationFrame {
	


    /**
     * Creates a new demo instance.
     *
     * @param title  the frame title.
     */

    public chart1(String title1) {
    	

        super(title1);
        

        final CategoryDataset dataset = createDataset();
        final JFreeChart chart = createChart(dataset);

        // add the chart to a panel...
        final ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        setContentPane(chartPanel);
    	
    }

    /**
     * Returns a sample dataset.
     * 
     * @return The dataset.
     */
     CategoryDataset createDataset() {
        
        // row keys...
 
        final String series1 = "IP Routing";
       final String series2 = "Selfisf Source Routing";
       final String series3 = "Selfish Overlay";
        // column keys...
        final String category1 = "Category 1";

        // create the dataset...
        final DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(IProuting.dip, series1, "");  //8888888888888888888888888888888888
	dataset.addValue(SSsource.dss, series2, "");
        dataset.addValue(SORouting.dso, series3, "");//88888888888888888888888888888888888
        
        
        return dataset;
        
    }
    
 
    /**
     * Creates a sample chart.
     * 
     * @param dataset  the dataset.
     * 
     * @return The chart.
     */
    JFreeChart createChart(final CategoryDataset dataset) {
        
        // create the chart...
         JFreeChart chart = ChartFactory.createBarChart(
            "Performance Of Different Routings",         // chart title
            "Types Of Routing",               // domain axis label
            "Average Latency (ms)",         // range axis label
            dataset,                  // data
            PlotOrientation.VERTICAL,
            true,                     // include legend
            true,                     // tooltips?
            false                     // URLs?
        );

        // NOW DO SOME OPTIONAL CUSTOMISATION OF THE CHART...

        // set the background color for the chart...
        chart.setBackgroundPaint(new Color(0xBBBBDD));

        // get a reference to the plot for further customisation...
        final CategoryPlot plot = chart.getCategoryPlot();
        
        // set the range axis to display integers only...
        final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());

        // disable bar outlines...
        final BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setDrawBarOutline(false);
        renderer.setMaximumBarWidth(0.10);
       // renderer.setMinimumBarLength();
        
        // set up gradient paints for series...
        final GradientPaint gp0 = new GradientPaint(
            0.0f, 0.0f, Color.blue, 
            0.0f, 0.0f, Color.lightGray
        );
        final GradientPaint gp1 = new GradientPaint(
            0.0f, 0.0f, Color.green, 
            0.0f, 0.0f, Color.lightGray
        );
        final GradientPaint gp2 = new GradientPaint(
            0.0f, 0.0f, Color.red, 
            0.0f, 0.0f, Color.lightGray
        );
        renderer.setSeriesPaint(0, gp0);
        renderer.setSeriesPaint(1, gp1);
        renderer.setSeriesPaint(2, gp2);
        
        // OPTIONAL CUSTOMISATION COMPLETED.
        
        return chart;
        
    }

    
    
    public static void main(final String[] args) {

        chart1 demo = new chart1("PERFORMANCE EVALUATION OF TCP-LP");
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        

    
}
}
