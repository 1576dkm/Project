/****************************************************************/
/*                      mainselfish	                            */
/*                                                              */
/****************************************************************/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import org.jfree.ui.RefineryUtilities;
import org.jfree.*;
import java.io.*;

/**
 * Summary description for mainselfish
 *
 */
public class mainselfish extends JFrame
{
	// Variables declaration
	private JTextArea jTextArea1;
	private JScrollPane jScrollPane1;
	private JButton jButton1;
	private JButton jButton2;
	private JButton jButton3;
	private JButton jButton4;
	private JButton jButton5;
	private JButton jButton6;
	private JPanel contentPane;
	// End of variables declaration


	public mainselfish()
	{
		super();
		initializeComponent();
		File f1 = new File("lat1.txt");
		File f2 = new File("lat2.txt");
		File f3 = new File("lat3.txt");
		if(f1.isFile())
		{
			f1.delete();
		}
		if(f2.isFile())
		{
			f2.delete();
		}
		if(f3.isFile())
		{
			f3.delete();
		}
		
		
		//
		// TODO: Add any constructor code after initializeComponent call
		//

		this.setVisible(true);
	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always regenerated
	 * by the Windows Form Designer. Otherwise, retrieving design might not work properly.
	 * Tip: If you must revise this method, please backup this GUI file for JFrameBuilder
	 * to retrieve your design properly in future, before revising this method.
	 */
	private void initializeComponent()
	{
		jTextArea1 = new JTextArea();
		jScrollPane1 = new JScrollPane();
		jButton1 = new JButton();
		jButton2 = new JButton();
		jButton3 = new JButton();
		jButton4 = new JButton();
		jButton5 = new JButton();
		jButton6 = new JButton();
		contentPane = (JPanel)this.getContentPane();

		//
		// jTextArea1
		//
		//
		// jScrollPane1
		//
		jScrollPane1.setViewportView(jTextArea1);
		//
		// jButton1
		//
		jButton1.setBackground(new Color(42, 43, 74));
		jButton1.setForeground(new Color(233, 219, 219));
		jButton1.setText("IP Routing");
		jButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton1_actionPerformed(e);
			}

		});
		//
		// jButton2
		//
		jButton2.setBackground(new Color(42, 43, 74));
		jButton2.setForeground(new Color(233, 219, 219));
		jButton2.setText("Selfish Source");
		jButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton2_actionPerformed(e);
			}

		});
		//
		// jButton3
		//
		jButton3.setBackground(new Color(42, 43, 74));
		jButton3.setForeground(new Color(233, 219, 219));
		jButton3.setText("Selfish Overlay");
		jButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton3_actionPerformed(e);
			}

		});
		//
		// jButton4
		//
		jButton4.setBackground(new Color(42, 43, 74));
		jButton4.setForeground(new Color(233, 219, 219));
		jButton4.setText("Comparison Chart");
		jButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton4_actionPerformed(e);
			}

		});
		//
		// jButton5
		//
		jButton5.setBackground(new Color(42, 43, 74));
		jButton5.setForeground(new Color(233, 219, 219));
		jButton5.setText("Help");
		jButton5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton5_actionPerformed(e);
			}

		});
		//
		// jButton6
		//
		jButton6.setBackground(new Color(42, 43, 74));
		jButton6.setForeground(new Color(233, 219, 219));
		jButton6.setText("Dismiss me");
		jButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				jButton6_actionPerformed(e);
			}

		});
		//
		// contentPane
		//
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(83, 90, 113));
		addComponent(contentPane, jScrollPane1, 26,29,290,230);
		addComponent(contentPane, jButton1, 326,27,153,51);
		addComponent(contentPane, jButton2, 327,78,152,52);
		addComponent(contentPane, jButton3, 329,131,150,49);
		addComponent(contentPane, jButton4, 331,180,149,50);
		addComponent(contentPane, jButton5, 331,230,150,47);
		addComponent(contentPane, jButton6, 97,268,186,34);
		//
		// mainselfish
		//
		this.setTitle("mainselfish - extends JFrame");
		this.setLocation(new Point(0, -1));
		this.setSize(new Dimension(512, 346));
	}

	/** Add Component Without a Layout Manager (Absolute Positioning) */
	private void addComponent(Container container,Component c,int x,int y,int width,int height)
	{
		c.setBounds(x,y,width,height);
		container.add(c);
	}

	//
	// TODO: Add any appropriate code in the following Event Handling Methods
	//
	private void jButton1_actionPerformed(ActionEvent e)
	{
		System.out.println("\njButton1_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
		new IProuting();

	}

	private void jButton2_actionPerformed(ActionEvent e)
	{
		System.out.println("\njButton2_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
		new SSsource();

	}

	private void jButton3_actionPerformed(ActionEvent e)
	{
		System.out.println("\njButton3_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
		new SORouting();

	}

	private void jButton4_actionPerformed(ActionEvent e)
	{
		System.out.println("\njButton4_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
	 final chart1 demo = new chart1("Line Chart Demo");
       
       demo.pack();
       RefineryUtilities.centerFrameOnScreen(demo);
      demo.setVisible(true);


	}

	private void jButton5_actionPerformed(ActionEvent e)
	{
		System.out.println("\njButton5_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
		jTextArea1.setText("Game Theoritic Aproach \n \n Communication networks shared by selfish users \n are considered and modeled as no cooperative repeated games. \n Each user is interested only in optimizing its own performance by controlling the routing. \n We investigate the existence of a IP that achieves the system-wide optimal cost.\n The existence of a IP that not only achieves the system-wide optimal cost \n but also yields a cost for each user no greater than its stage game NEP cost is shown \n for two-node multiple link networks");

	}

	private void jButton6_actionPerformed(ActionEvent e)
	{
		System.out.println("\njButton6_actionPerformed(ActionEvent e) called.");
		// TODO: Add any handling code here
		System.exit(0);

	}

	//
	// TODO: Add any method code to meet your needs in the following area
	//






























 

//============================= Testing ================================//
//=                                                                    =//
//= The following main method is just for testing this class you built.=//
//= After testing,you may simply delete it.                            =//
//======================================================================//
	public static void main(String[] args)
	{
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		try
		{
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		}
		catch (Exception ex)
		{
			System.out.println("Failed loading L&F: ");
			System.out.println(ex);
		}
		new mainselfish();
	}
//= End of Testing =


}
