import java.net.*;
import java.io.*;
class SOser
{
	public static void main(String args[])
	{
		try
		{
			ServerSocket ss=new ServerSocket(444);
			System.out.println("Destination...");
			while(true)
			{
				
				Socket s=ss.accept();
				DataInputStream in=new DataInputStream(s.getInputStream());
				byte b[]=new byte[in.available()];
				String source = in.readUTF();
				String dest = in.readUTF();
				String msg = in.readUTF();
				System.out.println("Source: "+source);
				System.out.println("Destination: "+dest);
				System.out.println("Received :"+msg);
				new SOdest(source, dest, msg);
				DataOutputStream out=new DataOutputStream(s.getOutputStream());
				out.writeUTF("I have received  message");
			}
		}
		catch(Exception e)
		{ e.printStackTrace(); }
	}
}