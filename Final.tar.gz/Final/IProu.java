import java.net.*;
import java.io.*;
import java.sql.*;
class IProu
{
		
	public static void main(String args[])
	
	{
		int flag=0;
		try
		{
			InetAddress ip=InetAddress.getLocalHost();
    	String localip = ip.getHostName();
    	 String fdest = null;
    	 String root = null;	

	/*	private String currnode = null;
		private String left = null;
		private String right = null;
		private String dest = null;
		private String msg = null; 
		private String fdest = null;
		private String root = null;
	*/
	
			ServerSocket ss=new ServerSocket(111);
			System.out.println("Router...");
			
			while(true)
			{
				Socket s=ss.accept();
				DataInputStream in=new DataInputStream(s.getInputStream());
			String sourceip=in.readUTF();
			String dest=in.readUTF();
			String msg=in.readUTF();
				 try
   		 			{
   	
  		 	Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
         			String dataSourceName = "router";
         			String dbURL = "jdbc:odbc:" + dataSourceName;
         			Connection con = DriverManager.getConnection(dbURL, "",""); 
   		 			Statement st = con.createStatement();
   		 			ResultSet rs = st.executeQuery("select * from CURR_TABLE ");
   		  
			   		  while(rs.next())
   		  				{
   			  		String currnode = rs.getString(1);
   			  		String left = rs.getString(2);
 			  		String right = rs.getString(3);
 			  			System.out.println("Left Node..."+left);
 			  			System.out.println("Right Node..."+right);
 			  			System.out.println("Current Node..."+currnode);
 			  // private String fdest = null;
   			  			if (currnode.equalsIgnoreCase(dest))
   			  			{
   				  		 fdest = currnode;
   				  			System.out.println("Checked Current Node..."+currnode);
							 flag=1;
   			  			}
   			  			else if (left.equalsIgnoreCase(dest)) {
   				  		 fdest = left;
   				  		System.out.println("Checked Left Node..."+left);
						 flag=1;
						}
   			  			else if (right.equalsIgnoreCase(dest)) {
   				  		 fdest = right;
   				  		System.out.println("Checked Right Node..."+right);
						 flag=1;
						}
   			  			else if(localip.equalsIgnoreCase(currnode))
   			  			{		  			
   				  			 
   					 		 root = rs.getString(4);
   					 		 fdest = root; 
   					 		System.out.println("Root Node For.."+currnode+"is.."+root);
   				  		}
   			  		break;	
   					}
   		  		// con.close();
   		 			}catch(Exception e2)
   		 			{
					e2.printStackTrace();//System.out.println(e2);
					}
				
				if(flag==1)
				{
				Socket reply=new Socket(fdest,222);
				DataOutputStream dos=new DataOutputStream(reply.getOutputStream());
				dos.writeUTF(sourceip);
				dos.writeUTF(dest);
				dos.writeUTF(msg);
				DataInputStream ser=new DataInputStream(reply.getInputStream());
				String ack = ser.readUTF();
				System.out.println(ack);
				DataOutputStream soc=new DataOutputStream(s.getOutputStream());
				soc.writeUTF(ack);
				}
				else
				{
				Socket s1 = new Socket(fdest, 111);	
				DataOutputStream dos1 = new DataOutputStream(s1.getOutputStream());
				dos1.writeUTF(dest);
				dos1.writeUTF(msg);
				DataInputStream dis1 = new DataInputStream(s1.getInputStream());
				String ackstr = dis1.readUTF();
				DataOutputStream soc=new DataOutputStream(s.getOutputStream());
				soc.writeUTF(ackstr);
				}
				
			/*	}catch(Exception e2)
   		 			{System.out.println(e2);}
			*/
			}
		}
		catch(Exception e)
		{ e.printStackTrace(); }
}	}