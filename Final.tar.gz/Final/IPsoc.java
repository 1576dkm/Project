import java.net.*;
import java.io.*;
import java.util.*;
class IPsoc
{
	static long favglat1;
	static long lat1;
	//Vector v = new Vector();
	IPsoc(String d1, String m1)
	{
		try
		{
			InetAddress ip=InetAddress.getLocalHost();
		     	String sourceip = ip.getHostName();
			String data = "";
			String nextnode = "";
			String msg = "";
			String data1 = "";
			
			int c, c1;
			String stravg = "";
			long start;
			long end;
			long lat;
			long avglat;
			long vsize;
			long avglat1 = 0;
			long favglat = 0;
			String dest;
			
			FileInputStream fnext = new FileInputStream("Next.txt");
      		while((c=fnext.read())!=-1)
	   		{
       		data = data+(char)c;
       		nextnode=data;
       		}

			// long start;
			// long end;
			// long lat;
			
			System.out.println("Source...");
			
	if(true)
	{
			Socket s=new Socket(nextnode, 111);
			DataOutputStream in=new DataOutputStream(s.getOutputStream());
		//	DataInputStream dis=new DataInputStream(System.in);
		//	System.out.println("Enter the destination address :");
		//	String dest=dis.readLine();
		//	System.out.println("Enter the message :");
		//	FileInputStream fin = new FileInputStream("msg.txt");
		
		/*	
		 while((c1=fnext.read())!=-1)
	   		{
       		data1 = data1+(char)c1;
       		msg=data1;
       		}
       		
       		 FileInputStream fileinputstream = new FileInputStream(str);
                        byte abyte0[] = new byte[fileinputstream.available()];
                        jt2.setText(str);
                        fileinputstream.read(abyte0);
                        String s = new String(abyte0);

       

			byte b[] = new byte[fin.available()];
		    fin.read(b);
		    msg = new String(b);
       		System.out.println(msg);
       		fin.close();
         */
	
			// String msg=dis.readLine();
			start=System.currentTimeMillis();// System.nanoTime();
			dest = d1;
			msg = m1;
			in.writeUTF(sourceip);
			in.writeUTF(dest);
			in.writeUTF(msg);
			DataInputStream inn=new DataInputStream(s.getInputStream());
			System.out.println("Received :"+inn.readUTF());
			end=System.currentTimeMillis();// System.nanoTime();
			lat = end - start;
			String strlatt = ""+lat+"#";
			FileOutputStream flat = new FileOutputStream("lat1.txt", true);
			
			flat.write(strlatt.trim().getBytes());
			lat1 = lat;
			
		/*	v.addElement(lat);
			vsize = v.size();
			System.out.println(v);
			System.out.println("Vector Size..."+vsize);
			Enumeration en = v.elements();
			while(en.hasMoreElements())
			{
				Object obj = en.nextElement();
				stravg = obj.toString();
				avglat = Long.parseLong(stravg);
				avglat1 = avglat1 + avglat;
				favglat = avglat1/vsize;
				System.out.println("string average..."+stravg);
				System.out.println("Long average..."+avglat);
			}
			System.out.println("Final Average Latency..."+favglat);
			favglat1 = favglat;
		*/		

	/*	for(Enumeration enumeration = modifyinfo.elements(); enumeration.hasMoreElements(); System.out.println(s1))
        {
            Object obj1 = enumeration.nextElement();
            s1 = obj1.toString();        }
    */
    
		System.out.println("Latency..."+lat);
	}
		}
		catch(Exception e)
		{ e.printStackTrace(); }
	}
public static void main(String args[])
{
// new IPsoc( d, m);
}
}