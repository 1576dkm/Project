import java.net.*;
import java.io.*;
import java.util.*;
class SOsoc
{
	static long lat1;
	SOsoc(String d, String m)
	{
		try
		{
			String data = "";
			String nextnode = "";
			String msg = "";
			String data1 = "";
			Vector v = new Vector();
			int c, c1;
			String stravg = "";
			long start;
			long end;
			long lat;
			long avglat;
			long vsize;
			long avglat1 = 0;
			long favglat = 0;
			String source = "";
			//static double dss;
			
			
		/*	FileInputStream fnext = new FileInputStream("Next.txt");
      		while((c=fnext.read())!=-1)
	   		{
       		data = data+(char)c;
       		nextnode=data;
       		}
		*/	
			// long start;
			// long end;
			// long lat;
			
			System.out.println("Source...");
			
	if(true)
	{
		/*	DataInputStream dis=new DataInputStream(System.in);
			System.out.println("Enter the destination address :");
			String dest=dis.readLine();
		*/
			String dest = d;
			SOhash sr = new SOhash(dest);
			String root = SOhash.froot;
				System.out.println("final root"+root);
			
			Socket s=new Socket(root, 333);
			DataOutputStream in=new DataOutputStream(s.getOutputStream());
			
		//	System.out.println("Enter the message :");
		//	FileInputStream fin = new FileInputStream("msg.txt");
		
		/*	
		 while((c1=fnext.read())!=-1)
	   		{
       		data1 = data1+(char)c1;
       		msg=data1;
       		}
       		
       		 FileInputStream fileinputstream = new FileInputStream(str);
                        byte abyte0[] = new byte[fileinputstream.available()];
                        jt2.setText(str);
                        fileinputstream.read(abyte0);
                        String s = new String(abyte0);

       	*/
       
        //	File f = new File("new.txt");
        
	
	
		/*	byte b[] = new byte[fin.available()];
		    fin.read(b);
		    msg = new String(b);
		*/
		msg = m;
       		System.out.println(msg);
       		// fin.close();
       		
       		InetAddress ip = InetAddress.getLocalHost();
		source = ip.getHostName();
		
			// String msg=dis.readLine();
			start=System.currentTimeMillis();
			in.writeUTF(source);
			in.writeUTF(dest);
			
			in.writeUTF(msg);
			DataInputStream inn=new DataInputStream(s.getInputStream());
			System.out.println("Received :"+inn.readUTF());
			end=System.currentTimeMillis();
			lat = end - start;
			String strlatt = ""+lat+"#";
			FileOutputStream flat = new FileOutputStream("lat3.txt", true);
			
			flat.write(strlatt.trim().getBytes());
			
			lat1 = lat;
			
			v.addElement(lat);
			vsize = v.size();
			System.out.println(v);
			System.out.println("Vector Size..."+vsize);
			Enumeration en = v.elements();
			while(en.hasMoreElements())
			{
				Object obj = en.nextElement();
				stravg = obj.toString();
				avglat = Long.parseLong(stravg);
				avglat1 = avglat1 + avglat;
				favglat = avglat1/vsize;
				System.out.println("string average..."+stravg);
				System.out.println("Long average..."+avglat);
			}
			System.out.println("Final Average Latency..."+favglat);
	/*	Long avg1 = new Long(favglat);
		double d = Double.valueOf(avg1);
		dss = d; 
	*/	
	/*	for(Enumeration enumeration = modifyinfo.elements(); enumeration.hasMoreElements(); System.out.println(s1))
        {
            Object obj1 = enumeration.nextElement();
            s1 = obj1.toString();
        }
    */
    
		System.out.println("Latency..."+lat);
	}
		}
		catch(Exception e)
		{ e.printStackTrace(); }
	}
public static void main(String args[])
{
// new SOsoc();
}
}